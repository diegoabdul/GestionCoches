<?php
	require('db.php');

	$sel_query="SELECT * FROM `poblacion`;";
	
	if ( isset($_REQUEST['idprovincia'])) {
		$sel_query="SELECT idpoblacion,poblacion  FROM `poblacion` where idprovincia=".$_REQUEST['idprovincia'].";";
	}
	
	$result = mysqli_query($con,$sel_query);
	
	// Se va a generar un JSON con la la info:

	$json = "[ "; // se deja espacio para que al quitar ?ltimo car?cter no rompa si no hay resultados
	while($row = mysqli_fetch_assoc($result)) { 
		$json = $json.'{"idpoblacion":'.$row["idpoblacion"].',"poblacion":"'.$row["poblacion"].'"},'; 
	}
	$json = substr($json, 0, -1)."]"; // se quita la ?ltima coma y se cierra el array
	
	// se devuelve el resultado
	echo utf8_encode($json);



?>