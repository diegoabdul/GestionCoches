var mymap;

$( document ).ready(function() {
	iniciarComboboxProvincias ();
	
	$( "#provincias" ).change(function() {
	  iniciarComboboxLocalidades();
	});
	
	$( "#localidades" ).change(function() {
		
		// tenemos que sacar el id de la provincia seleccionada
		latitud = $( "#localidades option:selected" ).attr('latitud');
		longitud = $( "#localidades option:selected" ).attr('longitud');
	
	  centrarMapa(latitud, longitud);
	});

	iniciarMapa ();
});



function iniciarComboboxProvincias () {
	console.log("Se inicia el combo de provincias");
	
	//se solicitan las provincias...
	$.get( "provincias_json.php", function( data ) {
		console.log( "datos descargados: " + data );
		
		// pasar de String a un array json
		var json = JSON.parse(data);
		
		$("#provincias").empty();
		$("#provincias").append("<option>Seleccione Provincia</option>");
		
		//console.log(json);
		json.forEach(function(obj) { 
			opcion = "<option value=\""+ obj.idprovincia + "\">"+ obj.provincia +"</option>"
			$("#provincias").append(opcion);
		});
	});
}

function iniciarComboboxLocalidades () {
	console.log("Se inicia el combo de LOCALIDADES");
	
	// tenemos que sacar el id de la provincia seleccionada
	idprovincia = $( "#provincias option:selected" ).val();
	
	
	//se solicitan las provincias...
	$.get( "localidades_coordenadas_json.php?idprovincia="+idprovincia, function( data ) {
		console.log("localidades_json.php?idprovincia="+idprovincia);
		console.log( "datos descargados: " + data );

		// pasar de String a un array json
		var json = JSON.parse(data);
		
		$("#localidades").empty();
		$("#localidades").append("<option>Seleccione Localidad</option>");
		
		//console.log(json);
		json.forEach(function(obj) { 
			opcion = '<option value="'+ obj.idpoblacion + '"'+
						'latitud="'+ obj.latitud + '"'+
						'longitud="'+ obj.longitud + '"'+
						'>'+ obj.poblacion +'</option>';
			$("#localidades").append(opcion);
		});

	});
}

function iniciarMapa () {
	
	console.log("iniciamos mapa");
	mymap = L.map('mapid').setView([51.505, -0.09], 13);

	L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
		maxZoom: 18,
		attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
			'<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
			'Imagery � <a href="https://www.mapbox.com/">Mapbox</a>',
		id: 'mapbox.streets'
	}).addTo(mymap);

	/*
	L.marker([51.5, -0.09]).addTo(mymap)
		.bindPopup("<b>Hello world!</b><br />I am a popup.").openPopup();
*/

}


function centrarMapa(latitud, longitud){
	console.log("lat: " + latitud + ", lon: " + longitud);
	
	mymap.setView([latitud, longitud],13);
}





